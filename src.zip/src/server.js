// সবার আগে .env লোড করো (প্রজেক্ট রুট থেকে, যেখান থেকেই চালাও না কেন)
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env") });

const app = require("./app");
const connectDB = require("./config/db");

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
};

startServer();
